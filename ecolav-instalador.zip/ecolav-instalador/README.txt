════════════════════════════════════════════════════════
  🏥 ECOLAV TOTEM v0.1.0 - Instalador Completo
════════════════════════════════════════════════════════

INSTALAÇÃO (2 passos):

1. Extrair o arquivo:
   unzip ecolav-instalador.zip
   cd ecolav-instalador

2. Executar instalador:
   sudo bash instalar.sh

PRONTO! ✅

════════════════════════════════════════════════════════
  🖱️  USAR O APLICATIVO:
════════════════════════════════════════════════════════

CLIQUE NO ÍCONE "ECOLAV Totem" no desktop

Ou execute: ecolav-completo

O ícone inicia automaticamente:
✅ Servidor da balança
✅ Aplicativo Ecolav Totem

════════════════════════════════════════════════════════
  ✅ CORREÇÕES INCLUÍDAS:
════════════════════════════════════════════════════════

✅ Balança: Suporte F/D/H/L
✅ Peso: Cálculo líquido (sem tara)
✅ Layout: Otimizado para 15"
✅ Servidor: Inicia automaticamente
✅ Um único ícone para tudo

════════════════════════════════════════════════════════
  📊 LOGS E TESTES:
════════════════════════════════════════════════════════

Ver logs: tail -f /var/log/ecolav/scale-server.log
Testar servidor: curl http://localhost:3001/scale/weight

════════════════════════════════════════════════════════
